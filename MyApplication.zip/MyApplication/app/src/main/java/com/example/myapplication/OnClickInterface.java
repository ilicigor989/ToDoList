package com.example.myapplication;

import android.support.constraint.ConstraintLayout;

public interface OnClickInterface {

    public void onItemSelected(Contacts contacts);
}
